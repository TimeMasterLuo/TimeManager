# TimeManager
An Android app that  provide a Time-managing service.
