package com.example.timemanager

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class FriendList : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_friend_list)
    }
}